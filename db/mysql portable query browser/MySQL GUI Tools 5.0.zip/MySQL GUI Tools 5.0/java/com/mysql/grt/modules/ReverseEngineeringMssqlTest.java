package com.mysql.grt.modules;

import junit.framework.TestCase;

/**
 * Test of ReverseEngineeringMssqlTest class
 * 
 * @author mike
 * @version 1.0, 11/29/04
 */
public class ReverseEngineeringMssqlTest extends TestCase
{

}
